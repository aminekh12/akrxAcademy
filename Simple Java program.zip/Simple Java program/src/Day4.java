public class Day4 {

    // Practical Examples
        // Student Information System
            // Class definition with public access




}



